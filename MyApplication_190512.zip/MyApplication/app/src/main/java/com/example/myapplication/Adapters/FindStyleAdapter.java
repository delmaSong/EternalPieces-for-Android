package com.example.myapplication.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.myapplication.Activities.DesignActivity;
import com.example.myapplication.Items.ItemFindStyle;
import com.example.myapplication.R;

import java.util.List;

/**
 * Created by Delma Song on 2019-05-02
 */
public class FindStyleAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private List<ItemFindStyle> mDataList;
    Context context;

    public FindStyleAdapter(List<ItemFindStyle> mDataList){
        this.mDataList = mDataList;
    }


    //뷰홀더 생성. 리사이클러뷰의 행(row)표시
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {

        TextView item_title;
        TextView item_contents;
        ToggleButton tb;


        //전체 루트 레이아웃에 해당하는 뷰가 들어옴

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            item_title =  (TextView)itemView.findViewById(R.id.item_title);
            item_contents = (TextView)itemView.findViewById(R.id.item_contents);
            tb = (ToggleButton)itemView.findViewById(R.id.item_tb1);
            itemView.setOnLongClickListener(this);

        }


        @Override
        public void onClick(View v) {
       //     delete(getAdapterPosition());
        }

        @Override
        public boolean onLongClick(View v) {
           delete(getAdapterPosition());
           return true;
        }

        public void delete(int position){

            try{
                mDataList.remove(position);
                notifyItemRemoved(position);
            }catch (IndexOutOfBoundsException e){
                e.printStackTrace();
            }
        }
    }



    @Override
    public RecyclerView.ViewHolder onCreateViewHolder (ViewGroup viewGroup, int i) {
       //inflater로 뷰를 얻음.
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_find_style, viewGroup, false);
        context = viewGroup.getContext();
        return new MyViewHolder(view);
    }
    //데이터 셋팅
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int i) {
       final MyViewHolder holder = (MyViewHolder) viewHolder;
        holder.item_title.setText(mDataList.get(i).getItem_title());
        holder.item_contents.setText(mDataList.get(i).getItem_contents());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                //    mListener.onItemClicked(i);
                    context.startActivity(new Intent(context, DesignActivity.class));
                }
            });
        holder.tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               holder.tb.setBackgroundDrawable(
                            context.getResources().getDrawable(R.drawable.like)
                    );

            }
        });

    }

    //이 어댑터가 가진 아이템 갯수 지정
    @Override
    public int getItemCount() {
        return mDataList.size();
    }

}
