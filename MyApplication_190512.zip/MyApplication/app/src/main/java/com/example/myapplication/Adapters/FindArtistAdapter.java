package com.example.myapplication.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.myapplication.Activities.TattooistMypageDesign;
import com.example.myapplication.Items.ItemFindArtist;
import com.example.myapplication.R;

import java.util.List;

/**
 * Created by Delma Song on 2019-05-03
 */
public class FindArtistAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private List<ItemFindArtist> mDataList;
    private Context context;

    public FindArtistAdapter(List<ItemFindArtist> mDataList) {
        this.mDataList = mDataList;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView item_id;
        TextView item_contents;
        ToggleButton tb;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            item_id = (TextView)itemView.findViewById(R.id.item_id);
            item_contents = (TextView)itemView.findViewById(R.id.item_contents);
            tb = (ToggleButton)itemView.findViewById(R.id.item_tb1);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_find_artist, viewGroup, false);
        context = viewGroup.getContext();
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final MyViewHolder holder =(MyViewHolder)viewHolder;
        holder.item_id.setText(mDataList.get(i).getItem_id());
        holder.item_contents.setText(mDataList.get(i).getItem_contents());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, TattooistMypageDesign.class));
            }
        });
        holder.tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.tb.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.like));
            }
        });

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }
}
