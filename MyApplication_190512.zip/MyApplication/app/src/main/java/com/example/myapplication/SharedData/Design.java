package com.example.myapplication.SharedData;

/**
 * Created by Delma Song on 2019-05-12
 */
public class Design {

    String name;
    String photo;
    int price;
    int size;
    int spendTime;
    String style;
    boolean liked;
    String tattooist;
    String designId;

    public Design() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getSpendTime() {
        return spendTime;
    }

    public void setSpendTime(int spendTime) {
        this.spendTime = spendTime;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public boolean isLiked() {
        return liked;
    }

    public void setLiked(boolean liked) {
        this.liked = liked;
    }

    public String getTattooist() {
        return tattooist;
    }

    public void setTattooist(String tattooist) {
        this.tattooist = tattooist;
    }

    public String getDesignId() {
        return designId;
    }

    public void setDesignId(String designId) {
        this.designId = designId;
    }

    @Override
    public String toString() {
        return "Design{" +
                "name='" + name + '\'' +
                ", photo='" + photo + '\'' +
                ", price=" + price +
                ", size=" + size +
                ", spendTime=" + spendTime +
                ", style='" + style + '\'' +
                ", liked=" + liked +
                ", tattooist='" + tattooist + '\'' +
                ", designId='" + designId + '\'' +
                '}';
    }
}

