package com.example.myapplication.Activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myapplication.Adapters.FindStyleAdapter;
import com.example.myapplication.Items.ItemFindStyle;
import com.example.myapplication.R;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;


public class UploadDesign extends AppCompatActivity implements View.OnClickListener{

    public Context context;
    ImageButton buttonBack;
    Button btn_ok;
    ImageView imageView;
    Button btn_upload_img;
    EditText tv_design_name;
    EditText et_price;
    EditText et_time;
    EditText et_size;
    Spinner sp_style;
    String selectedSpinner;     //선택된 스피너 값 저장
    EditText et_comment;

    ArrayList styleList;
    ArrayAdapter arrayAdapter;



    private static final int PICK_FROM_CAMERA = 0;
    private static final int PICK_FROM_ALBUM = 1;
    private static final int CROP_FROM_IMAGE = 2;

    private Uri mImageCatrueUri;
    private int id_view;
    private String absolutePath;



    //for Drawer
    DrawerLayout dl;
    View drawer;
    ImageButton btnOpenDrawer;
    ImageButton btnCloseDrawer;

    //드로어 내부 버튼
    Button btnFindStyle;
    Button btnFindArtist;
    Button btnMypage;
    Button btnChatList;
    Button btnBookingList;
    Button btnUploadDesign;
    Button btnUploadWork;
    Button btnLike;


    //데이터 임시 저장할 리스트
    List<ItemFindStyle> dataList;



    //카메라에서 사진 촬영
    public void doTakePhotoAction(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


        //임시로 사용할 파일의 경로를 생성
        String url = "tmp_"+String.valueOf(System.currentTimeMillis())+".jpg";
       // mImageCatrueUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(), url));
        File file = new File(url);
        mImageCatrueUri = FileProvider.getUriForFile(UploadDesign.this, "com.test.fileprovider", file);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageCatrueUri);
        startActivityForResult(intent, PICK_FROM_CAMERA);

    }




    //앨범에서 이미지 가져오기
    public void doTakeAlbumAction(){
        //앨범 호출
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK){
            return;
        }

        switch (requestCode){
            case PICK_FROM_ALBUM:{
                mImageCatrueUri = data.getData();
                Log.d("SmartWheel", mImageCatrueUri.getPath().toString());
            }

            case PICK_FROM_CAMERA :{
                Intent intent = new Intent("com.android.camera.action.CROP");
                intent.setDataAndType(mImageCatrueUri, "image/*");

                intent.putExtra("outputX", 200);    //crop한 이미지의 x축 크기
                intent.putExtra("outputY", 200);    //crop한 이미지의 y축 크기
                intent.putExtra("aspectX", 1);      //crop 박스의 x축 비율
                intent.putExtra("aspectY", 1);      //crop 박스의 y축 비율
                intent.putExtra("scale", true);
                intent.putExtra("return-data", true);
                startActivityForResult(intent, CROP_FROM_IMAGE);
                break;
            }

            case CROP_FROM_IMAGE : {
                if(resultCode != RESULT_OK){
                    return;
                }

                final Bundle extras = data.getExtras();

                //crop된 이미지를 저장하기 위한 file 경로
                String filePath = Environment.getExternalStorageDirectory().getAbsolutePath() +
                        "/SmartWheel/"+System.currentTimeMillis()+".jpg";

                if(extras != null){
                    Bitmap photo = extras.getParcelable("data");        //crop된 bitmap
                    imageView.setImageBitmap(photo);

                    storeCropImage(photo, filePath);      //crop된 이미지를 외부저장소, 앨범에 저장.
                    absolutePath = filePath;
                    break;
                }

                //임시 파일 삭제
                File f = new File(mImageCatrueUri.getPath());
                if(f.exists()){
                    f.delete();
                }
            }
        }
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_upload_img) {
            DialogInterface.OnClickListener cameraListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    doTakePhotoAction();
                }
            };
            DialogInterface.OnClickListener albumListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    doTakeAlbumAction();
                }
            };
            DialogInterface.OnClickListener cancelListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            };

            new AlertDialog.Builder(this)
                    .setTitle("업로드 할 이미지 선택")
                    .setPositiveButton("사진 촬영", cameraListener)
                    .setNeutralButton("앨범 선택", albumListener)
                    .setNegativeButton("취소", cancelListener)
                    .show();


        }
        Toast.makeText(UploadDesign.this, "왜안뜰까,,," ,Toast.LENGTH_LONG);
    }


    //bitmap 저장하는 부분
    private  void storeCropImage(Bitmap bitmap, String filePath){
        //SmartWheel 폴더를 생성해 이미지를 저장하는 방식
        String dirPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/SmartWheel";
        File directory_SmartWheel = new File(dirPath);

        if(!directory_SmartWheel.exists()){
            directory_SmartWheel.mkdir();
        }

        File copyFile = new File(filePath);
        BufferedOutputStream out = null;

        try{

            copyFile.createNewFile();
            out = new BufferedOutputStream(new FileOutputStream(copyFile));
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

            //sendBroadCast를 통해 crop된 사진을 앨범에 보이도록 갱신.
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(copyFile)));
        }catch (Exception e){
            e.printStackTrace();
        }


    }






    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_design);

        buttonBack = (ImageButton)findViewById(R.id.buttonBack);
        imageView = (ImageView)findViewById(R.id.imageView);
        btn_upload_img = (Button)findViewById(R.id.btn_upload_img);
        tv_design_name = (EditText)findViewById(R.id.tv_design_name);
        et_price = (EditText)findViewById(R.id.et_price);
        et_time = (EditText)findViewById(R.id.et_time);
        et_size = (EditText)findViewById(R.id.et_size);
        btn_ok = (Button)findViewById(R.id.btn_ok);
        et_comment = (EditText)findViewById(R.id.et_comment);

        //spinner
        styleList = new ArrayList();

        styleList.add("레터링");
        styleList.add("이레즈미");
        styleList.add("블랙앤그레이");
        styleList.add("수채화");
        styleList.add("커버업");
        styleList.add("올드스쿨");
        styleList.add("미니타투");

        arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, styleList);
        sp_style = (Spinner)findViewById(R.id.sp_style);
        sp_style.setAdapter(arrayAdapter);
        sp_style.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), styleList.get(position)+"가 선택되었습니다", Toast.LENGTH_SHORT).show();
                selectedSpinner = styleList.get(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        //드로어 내부 버튼
        btnFindStyle = (Button)findViewById(R.id.btn_find_style);
        btnFindArtist = (Button)findViewById(R.id.btn_find_artist);
        btnMypage = (Button)findViewById(R.id.btn_mypage);
        btnChatList = (Button)findViewById(R.id.btn_chat_list);
        btnBookingList = (Button)findViewById(R.id.btn_booking_list);
        btnUploadDesign = (Button)findViewById(R.id.btn_upload_design);
        btnUploadWork = (Button)findViewById(R.id.btn_upload_work);
        btnLike = (Button)findViewById(R.id.btn_like);



        dl = (DrawerLayout)findViewById(R.id.dl_upload_design);
        drawer = (View)findViewById(R.id.dl_drawer);

        btnOpenDrawer = (ImageButton) findViewById(R.id.btnOpenDrawer);
        btnCloseDrawer = (ImageButton) findViewById(R.id.btnCloseDrawer);

        //드로어 오픈 버튼
        btnOpenDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.openDrawer(drawer);
            }
        });

        //드로어 클로즈 버튼
        btnCloseDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.closeDrawer(drawer);
            }
        });


    }


    protected void onResume(){
        super.onResume();
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btnFindStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, FindStyleActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnFindArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, FindArtistActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnMypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, TattooistMypageDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btnChatList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, TattooistChatList.class);
                startActivity(intent);
                finish();
            }
        });

        btnBookingList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, TattooistBookingList.class);
                startActivity(intent);
                finish();
            }
        });

        btnUploadDesign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, UploadDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btnUploadWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, UploadWork.class);
                startActivity(intent);
                finish();
            }
        });

        btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, LikeDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadDesign.this, FindStyleActivity.class);
                intent.putExtra("tv_design_name", tv_design_name.getText().toString());
                intent.putExtra("et_price", et_price.getText().toString());
                intent.putExtra("et_time", et_time.getText().toString());
                intent.putExtra("et_size", et_size.getText().toString());
                intent.putExtra("sp_style", selectedSpinner);
                intent.putExtra("et_comment", et_comment.getText().toString());

//                Intent intent2 = new Intent(UploadDesign.this, TattooistMypageDesign.class);
//                intent2.putExtra("tv_design_name", tv_design_name.getText().toString());
//                intent2.putExtra("et_price", et_price.getText().toString());
//                intent2.putExtra("et_time", et_time.getText().toString());
//                intent2.putExtra("et_size", et_size.getText().toString());
//                intent2.putExtra("sp_style", selectedSpinner);
//                intent2.putExtra("et_comment", et_comment.getText().toString());

                setResult(RESULT_OK, intent);
//                setResult(RESULT_OK, intent2);
                finish();


            }
        });


    }

}
