package com.example.myapplication.SharedData;

import java.util.Date;

/**
 * Created by Delma Song on 2019-05-12
 */
public class Review {

    String writer;      //작성자(user id)
    int reviewNo;       //리뷰 넘버(작성자가 여러 후기 쓸 수 있으므로)
    String contents;    //후기 내용
    Date date;          //작성 날짜
    String photo;       //후기 사진
    float star;         //별점
    String repleId;        //댓글 키값

    public Review() {
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public int getReviewNo() {
        return reviewNo;
    }

    public void setReviewNo(int reviewNo) {
        this.reviewNo = reviewNo;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public float getStar() {
        return star;
    }

    public void setStar(float star) {
        this.star = star;
    }

    public String getRepleId() {
        return repleId;
    }

    public void setRepleId(String repleId) {
        this.repleId = repleId;
    }

    @Override
    public String toString() {
        return "Review{" +
                "writer='" + writer + '\'' +
                ", reviewNo=" + reviewNo +
                ", contents='" + contents + '\'' +
                ", date=" + date +
                ", photo='" + photo + '\'' +
                ", star=" + star +
                ", repleId='" + repleId + '\'' +
                '}';
    }
}


