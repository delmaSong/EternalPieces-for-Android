package com.example.myapplication.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.SharedData.Tattooist;
import com.example.myapplication.SharedData.User;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JoinTattooistActivity extends AppCompatActivity {


    EditText et_address;
    EditText et_introduce;

    Button button_cancel;
    Button button_ok;
    Button button_find;

    Spinner sp_style1;
    Spinner sp_style2;
    Spinner sp_style3;

    //스트링 형태로 값 받을 변수들
    String s_address, s_introduce, s_style1, s_style2, s_style3;

    //스피너 생성할때 쓸 변수
    ArrayList styleList;
    ArrayAdapter arrayAdapter;

    //스타일 어레이 저장할 놈
    List<String> myStyle;

    String userid;      //회원가입 때 저장한 id 값
    String userpw;      //회원가입 때 저장한 pw 값

    Gson gson;
    String json_tattooist, json_user;
    Tattooist tattooist;
    User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstancedState){
        super.onCreate(savedInstancedState);
        setContentView(R.layout.activity_join_tattooist);


        et_address = (EditText)findViewById(R.id.et_address);
        et_introduce = (EditText)findViewById(R.id.et_introduce);

        button_cancel = (Button)findViewById(R.id.button_cancel);
        button_ok = (Button)findViewById(R.id.btn_ok);
        button_find = (Button)findViewById(R.id.button_find);




        //쓰던 데이터 있으면 받아오기
        Intent intent = getIntent();
        userid = intent.getStringExtra("userid_key");
        userpw = intent.getStringExtra("userpw_key");


        //저장된 데이터 있을시 복원
        if(savedInstancedState != null){
            String data_adrs = savedInstancedState.getString(s_address);
            String data_introduce = savedInstancedState.getString(s_introduce);


            et_address.setText(data_adrs);
            et_introduce.setText(data_introduce);
        }


        //스피너 목록 생성
        styleList = new ArrayList();
        myStyle = new ArrayList<>();

        styleList.add("레터링");
        styleList.add("블랙앤그레이");
        styleList.add("수채화");
        styleList.add("커버업");
        styleList.add("크레용");

        arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, styleList);
        sp_style1 = (Spinner)findViewById(R.id.sp_style1);
        sp_style1.setAdapter(arrayAdapter);

        sp_style2 = (Spinner)findViewById(R.id.sp_style2);
        sp_style2.setAdapter(arrayAdapter);

        sp_style3 = (Spinner)findViewById(R.id.sp_style3);
        sp_style3.setAdapter(arrayAdapter);






        sp_style1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                myStyle.add(styleList.get(position).toString());
                // s_style1 = styleList.get(position).toString();
                //    Toast.makeText(getApplicationContext(), styleList.get(position)+"가 선택되었습니다", Toast.LENGTH_SHORT).show();
                for (int i=0; i<myStyle.size(); i++){

                    Log.d("myStyle에 들어갔는지 1111", myStyle.get(i));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp_style2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //  s_style2 = styleList.get(position).toString();
                myStyle.add(styleList.get(position).toString());
                //     Toast.makeText(getApplicationContext(), styleList.get(position)+"가 선택되었습니다", Toast.LENGTH_SHORT).show();
                for (int i=0; i<myStyle.size(); i++){

                    Log.d("myStyle에 들어갔는지222", myStyle.get(i));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        sp_style3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                        s_style3 = styleList.get(position).toString();
                myStyle.add(styleList.get(position).toString());
                //      Toast.makeText(getApplicationContext(), styleList.get(position)+"가 선택되었습니다", Toast.LENGTH_SHORT).show();
                for (int i=0; i<myStyle.size(); i++){

                    Log.d("myStyle에 들어갔는지3333", myStyle.get(i));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        //취소 버튼 선택시
        button_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(JoinTattooistActivity.this, JoinActivity.class);
                intent.putExtra("userid_key", userid);
                intent.putExtra("userpw_key", userpw);
                startActivity(intent);
                finish();

            }
        });









        //확인 버튼 선택시
        button_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //주소 미입력시
                if(et_address.getText().toString().length() == 0){
                    Toast.makeText(JoinTattooistActivity.this, "주소를 입력해주세요", Toast.LENGTH_SHORT).show();
                    et_address.requestFocus();
                    return;
                }

                //간단한 소개 미입력시
                if(et_introduce.getText().toString().length() == 0){
                    Toast.makeText(JoinTattooistActivity.this, "간단한 소개를 입력해주세요", Toast.LENGTH_SHORT).show();
                    et_introduce.requestFocus();
                    return;
                }

                Intent intent =getIntent();
                user = intent.getParcelableExtra("user_key");

                String userId = user.getId();

                tattooist = new Tattooist();
                tattooist.setId(userId);
                tattooist.setAddress(et_address.getText().toString());
                tattooist.setProfile(et_introduce.getText().toString());
                tattooist.setStyle(myStyle);
//                tattooist.setStyle(myStyle);
//                tattooist.setStyle(s_style2);
//                tattooist.setStyle(s_style3);






                //shared preference에 데이터 삽입
                SharedPreferences sp_tattooist = getSharedPreferences("tattooist", MODE_PRIVATE);       //tattooist라는 이름의 xml 파일 선언
                SharedPreferences.Editor editor = sp_tattooist.edit();      //쉐어드 tattooist에서 쓰는 에디터 선언

                gson = new Gson();

                //to save

                json_tattooist = gson.toJson(tattooist);
                editor.putString(userId, json_tattooist);     //앞 액티비티에서 저장한 유저의 아이디를 키값으로 설정해 타투이스트의 정보를 저장,,,,,,
                editor.apply();
                Log.d("Tatt_check", sp_tattooist.getAll().toString());

//            editor.putString("style1", s_style1);
//            editor.putString("style2", s_style2);
//            editor.putString("style3", s_style3);
//            editor.putString("address", s_address);
//            editor.putString("introduce", s_introduce);
//            editor.commit();



//                Intent intent = new Intent(JoinTattooistActivity.this, SetWorktimeWhenJoin.class);
//                intent.putExtra("address_key", s_address);
//                intent.putExtra("introduce_key", s_introduce);
//                intent.putExtra("sp_style1_key", s_style1);
//                intent.putExtra("sp_style2_key", s_style2);
//                intent.putExtra("sp_style3_key", s_style3);
//                intent.putExtra("userid_key", userid);
//                intent.putExtra("userpw_key", userpw);

 //               startActivity(intent);
//                finish();
            }
        });





//
//        //shared preference에 데이터 삽입
//        SharedPreferences sp_tattooist = getSharedPreferences("tattooist", MODE_PRIVATE);       //tattooist라는 이름의 xml 파일 선언
//        SharedPreferences.Editor editor = sp_tattooist.edit();      //쉐어드 tattooist에서 쓰는 에디터 선언
//
//        SharedPreferences sp_user = getSharedPreferences("user", MODE_PRIVATE);     //user 이름의  xml파일 선언
//        gson = new Gson();
//        json_user = sp_user.getString("userid", "");        //user.xml에 저장된 user정보 끌어옴.. 키값이 ... 끌어와질까,,,?
//        user = gson.fromJson(json_user, User.class);
//        String userId = user.getId();
//
//        json_tattooist = gson.toJson(tattooist);
//        editor.putString(userId, json_tattooist);     //유저의 아이디값을 키값으로 삼아 데이터를 저장하고싶은데,, tattooist.xmldㅔ... 그러려면 먼저 user.xml에 저장된 데이터를 끌어와야겠네,, 근데 인텐트로 보내줬단말이지?
//        editor.apply();
//
////            editor.putString("style1", s_style1);
////            editor.putString("style2", s_style2);
////            editor.putString("style3", s_style3);
////            editor.putString("address", s_address);
////            editor.putString("introduce", s_introduce);
////            editor.commit();











    }



    //onPause()실행 되기 전에 여기 들려서 번들에 데이터 저장한다.
    @Override
    protected void onSaveInstanceState(Bundle savedBundle){
        super.onSaveInstanceState(savedBundle);

        String data_adrs = et_address.getText().toString();
        String data_introduce = et_introduce.getText().toString();

        savedBundle.putString("useradrs_key", data_adrs);
        savedBundle.putString("userintroduce_key", data_introduce);
    }



}
