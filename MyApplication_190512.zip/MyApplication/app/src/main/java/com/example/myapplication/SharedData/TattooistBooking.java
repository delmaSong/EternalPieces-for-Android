package com.example.myapplication.SharedData;

import java.sql.Time;
import java.util.Date;

/**
 * Created by Delma Song on 2019-05-12
 */
public class TattooistBooking {

    Date date;      //날짜
    Time time;      //시간
    int price;
    String bodyPart;
    int size;
    String design;              //도
    String bookerComment;       //예약자 당부사항,코멘트
    String bookerId;            //예약자 id
    String bookingId;           //예약 id.. 타투이스트 아이디 + 번호

    public TattooistBooking() {
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getBodyPart() {
        return bodyPart;
    }

    public void setBodyPart(String bodyPart) {
        this.bodyPart = bodyPart;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getDesign() {
        return design;
    }

    public void setDesign(String design) {
        this.design = design;
    }

    public String getBookerComment() {
        return bookerComment;
    }

    public void setBookerComment(String bookerComment) {
        this.bookerComment = bookerComment;
    }

    public String getBookerId() {
        return bookerId;
    }

    public void setBookerId(String bookerId) {
        this.bookerId = bookerId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }


    @Override
    public String toString() {
        return "TattooistBooking{" +
                "date=" + date +
                ", time=" + time +
                ", price=" + price +
                ", bodyPart='" + bodyPart + '\'' +
                ", size=" + size +
                ", design='" + design + '\'' +
                ", bookerComment='" + bookerComment + '\'' +
                ", bookerId='" + bookerId + '\'' +
                ", bookingId='" + bookingId + '\'' +
                '}';
    }
}


