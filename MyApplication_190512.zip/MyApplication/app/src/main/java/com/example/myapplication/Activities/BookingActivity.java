package com.example.myapplication.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;

public class BookingActivity extends AppCompatActivity {

    Button buttonBack;
    Button buttonToPay;

    Spinner partOfBody;
    Spinner size;

    ArrayList partList;
    ArrayList sizeList;
    ArrayAdapter partAdapter;
    ArrayAdapter sizeAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        buttonBack = (Button)findViewById(R.id.buttonBack);
        buttonToPay = (Button)findViewById(R.id.buttonToPay);

        partOfBody = (Spinner)findViewById(R.id.partOfBody);
        size = (Spinner)findViewById(R.id.size);


        partList = new ArrayList();
        partList.add("부위를 선택해주세요");
        partList.add("팔 상단");
        partList.add("팔 하단");
        partList.add("다리 상단");
        partList.add("다리 하단");
        partList.add("손등");
        partList.add("발등");
        partList.add("등");
        partList.add("기타 부위");

        partAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, partList);

        partOfBody.setAdapter(partAdapter);
        partOfBody.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(BookingActivity.this, partList.get(position)+"(이)가 선택되었습니다", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        sizeList = new ArrayList();
        sizeList.add("사이즈를 선택해주세요");
        sizeList.add("5cm 미만(미니)");
        sizeList.add("5cm-7cm");
        sizeList.add("8cm-10cm");
        sizeList.add("11cm-15cm");
        sizeList.add("15cm 이상");

        sizeAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, sizeList);

        size.setAdapter(sizeAdapter);
        size.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(BookingActivity.this, sizeList.get(position)+"가 선택되었습니다", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onResume(){
        super.onResume();

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        buttonToPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookingActivity.this, PayActivity.class);
                startActivity(intent);
            }
        });

        //도안 화면에서 정보 받아야 함. 사이즈, 부위, 센치, 아티스트 등등

    }
}
