package com.example.myapplication.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.Activities.WriteReview;
import com.example.myapplication.Items.ItemTattooerBookingList;
import com.example.myapplication.R;

import java.util.List;

/**
 * Created by Delma Song on 2019-05-04
 */
public class TattooerBookingListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ItemTattooerBookingList> mDataList;
    public Context context;


    public TattooerBookingListAdapter(List<ItemTattooerBookingList> mDataList) {
        this.mDataList = mDataList;
    }

    public static class MyRecycleViewHolder extends RecyclerView.ViewHolder{
        ImageView item_img;
        TextView item_date, item_adrs, item_sum, item_worker, item_part, item_size, item_req,
         item_date2, item_adrs2, item_sum2, item_worker2, item_part2, item_size2, item_req2;

        public MyRecycleViewHolder(@NonNull View itemView) {
            super(itemView);
            item_img = (ImageView)itemView.findViewById(R.id.item_img);

            item_date = (TextView)itemView.findViewById(R.id.item_date);
            item_adrs = (TextView)itemView.findViewById(R.id.item_adrs);
            item_sum = (TextView)itemView.findViewById(R.id.item_sum);
            item_worker = (TextView)itemView.findViewById(R.id.item_worker);
            item_part = (TextView)itemView.findViewById(R.id.item_part);
            item_size = (TextView)itemView.findViewById(R.id.item_size);
            item_req = (TextView)itemView.findViewById(R.id.item_req);

            item_date2 = (TextView)itemView.findViewById(R.id.item_date2);
            item_adrs2 = (TextView)itemView.findViewById(R.id.item_adrs2);
            item_sum2 = (TextView)itemView.findViewById(R.id.item_sum2);
            item_worker2 = (TextView)itemView.findViewById(R.id.item_worker2);
            item_part2 = (TextView)itemView.findViewById(R.id.item_part2);
            item_size2 = (TextView)itemView.findViewById(R.id.item_size2);
            item_req2 = (TextView)itemView.findViewById(R.id.item_req2);



        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_booking_tattooer, viewGroup, false);
        context = viewGroup.getContext();
        return new MyRecycleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final MyRecycleViewHolder holder = (MyRecycleViewHolder)viewHolder;
        holder.item_img.setImageResource(mDataList.get(i).getItem_img());

        holder.item_date.setText(mDataList.get(i).getItem_date());
        holder.item_adrs.setText(mDataList.get(i).getItem_adrs());
        holder.item_sum.setText(mDataList.get(i).getItem_sum());
        holder.item_worker.setText(mDataList.get(i).getItem_worker());
        holder.item_part.setText(mDataList.get(i).getItem_part());
        holder.item_size.setText(mDataList.get(i).getItem_size());
        holder.item_req.setText(mDataList.get(i).getItem_req());

        holder.item_date2.setText(mDataList.get(i).getItem_date2());
        holder.item_adrs2.setText(mDataList.get(i).getItem_adrs2());
        holder.item_sum2.setText(mDataList.get(i).getItem_sum2());
        holder.item_worker2.setText(mDataList.get(i).getItem_worker2());
        holder.item_part2.setText(mDataList.get(i).getItem_part2());
        holder.item_size2.setText(mDataList.get(i).getItem_size2());
        holder.item_req2.setText(mDataList.get(i).getItem_req2());




    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }
}
