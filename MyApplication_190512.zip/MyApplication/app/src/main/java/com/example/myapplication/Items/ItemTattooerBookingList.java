package com.example.myapplication.Items;

/**
 * Created by Delma Song on 2019-05-04
 */
public class ItemTattooerBookingList {

    int item_img;
    int btn_write_review;
    String item_date, item_adrs, item_sum, item_worker, item_part, item_size, item_req;
    String item_date2, item_adrs2, item_sum2, item_worker2, item_part2, item_size2, item_req2;

    public ItemTattooerBookingList(int item_img, int btn_write_review, String item_date, String item_adrs, String item_sum, String item_worker, String item_part, String item_size, String item_req, String item_date2, String item_adrs2, String item_sum2, String item_worker2, String item_part2, String item_size2, String item_req2) {
        this.item_img = item_img;
        this.btn_write_review = btn_write_review;
        this.item_date = item_date;
        this.item_adrs = item_adrs;
        this.item_sum = item_sum;
        this.item_worker = item_worker;
        this.item_part = item_part;
        this.item_size = item_size;
        this.item_req = item_req;
        this.item_date2 = item_date2;
        this.item_adrs2 = item_adrs2;
        this.item_sum2 = item_sum2;
        this.item_worker2 = item_worker2;
        this.item_part2 = item_part2;
        this.item_size2 = item_size2;
        this.item_req2 = item_req2;
    }

    public int getItem_img() {
        return item_img;
    }

    public void setItem_img(int item_img) {
        this.item_img = item_img;
    }

    public int getBtn_write_review() {
        return btn_write_review;
    }

    public void setBtn_write_review(int btn_write_review) {
        this.btn_write_review = btn_write_review;
    }

    public String getItem_date() {
        return item_date;
    }

    public void setItem_date(String item_date) {
        this.item_date = item_date;
    }

    public String getItem_adrs() {
        return item_adrs;
    }

    public void setItem_adrs(String item_adrs) {
        this.item_adrs = item_adrs;
    }

    public String getItem_sum() {
        return item_sum;
    }

    public void setItem_sum(String item_sum) {
        this.item_sum = item_sum;
    }

    public String getItem_worker() {
        return item_worker;
    }

    public void setItem_worker(String item_worker) {
        this.item_worker = item_worker;
    }

    public String getItem_part() {
        return item_part;
    }

    public void setItem_part(String item_part) {
        this.item_part = item_part;
    }

    public String getItem_size() {
        return item_size;
    }

    public void setItem_size(String item_size) {
        this.item_size = item_size;
    }

    public String getItem_req() {
        return item_req;
    }

    public void setItem_req(String item_req) {
        this.item_req = item_req;
    }

    public String getItem_date2() {
        return item_date2;
    }

    public void setItem_date2(String item_date2) {
        this.item_date2 = item_date2;
    }

    public String getItem_adrs2() {
        return item_adrs2;
    }

    public void setItem_adrs2(String item_adrs2) {
        this.item_adrs2 = item_adrs2;
    }

    public String getItem_sum2() {
        return item_sum2;
    }

    public void setItem_sum2(String item_sum2) {
        this.item_sum2 = item_sum2;
    }

    public String getItem_worker2() {
        return item_worker2;
    }

    public void setItem_worker2(String item_worker2) {
        this.item_worker2 = item_worker2;
    }

    public String getItem_part2() {
        return item_part2;
    }

    public void setItem_part2(String item_part2) {
        this.item_part2 = item_part2;
    }

    public String getItem_size2() {
        return item_size2;
    }

    public void setItem_size2(String item_size2) {
        this.item_size2 = item_size2;
    }

    public String getItem_req2() {
        return item_req2;
    }

    public void setItem_req2(String item_req2) {
        this.item_req2 = item_req2;
    }
}
