package com.example.myapplication.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.myapplication.R;

public class DesignActivity extends AppCompatActivity {

    Button buttonChat;
    Button buttonBooking;
    ImageButton buttonBack;

    DrawerLayout dl;
    View drawer;

    ImageButton btnOpenDrawer;
    ImageButton btnCloseDrawer;

    TextView ct_desing_name, ct_tattooist, ct_size, ct_price, ct_time;

    //드로어 내부 버튼
    Button btnFindStyle;
    Button btnFindArtist;
    Button btnMypage;
    Button btnChatList;
    Button btnBookingList;
    Button btnUploadDesign;
    Button btnUploadWork;
    Button btnLike;

    //데이터 값 임시 저장
    String desing_name;
    String size;
    String price;
    String time;
    String style;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design);

        buttonChat = (Button)findViewById(R.id.buttonChat);
        buttonBooking = (Button)findViewById(R.id.buttonBooking);
        buttonBack = (ImageButton) findViewById(R.id.buttonBack);

        ct_desing_name = (TextView)findViewById(R.id.ct_design_name);
        ct_tattooist = (TextView)findViewById(R.id.ct_tattooist);
        ct_size = (TextView)findViewById(R.id.ct_size);
        ct_price = (TextView)findViewById(R.id.ct_price);
        ct_time = (TextView)findViewById(R.id.ct_time);


        //드로어 내부 버튼
        btnFindStyle = (Button)findViewById(R.id.btn_find_style);
        btnFindArtist = (Button)findViewById(R.id.btn_find_artist);
        btnMypage = (Button)findViewById(R.id.btn_mypage);
        btnChatList = (Button)findViewById(R.id.btn_chat_list);
        btnBookingList = (Button)findViewById(R.id.btn_booking_list);
        btnUploadDesign = (Button)findViewById(R.id.btn_upload_design);
        btnUploadWork = (Button)findViewById(R.id.btn_upload_work);
        btnLike = (Button)findViewById(R.id.btn_like);


        dl = (DrawerLayout)findViewById(R.id.dl_design);
        drawer = (View)findViewById(R.id.dl_drawer);

        btnOpenDrawer = (ImageButton) findViewById(R.id.btnOpenDrawer);
        btnCloseDrawer = (ImageButton) findViewById(R.id.btnCloseDrawer);

        //드로어 오픈 버튼
        btnOpenDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.openDrawer(drawer);
            }
        });

        //드로어 클로즈 버튼
        btnCloseDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.closeDrawer(drawer);
            }
        });


        //좋아요 버튼
        final ToggleButton tb = (ToggleButton)findViewById(R.id.tb1);
        tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tb.isChecked()){         //좋아요 클릭시.. 지금은 이미지만 변경. 추후에 좋아요 클릭시 데이터 모아 좋아요 액티비티에 전달..
                    tb.setBackgroundDrawable(
                            getResources().getDrawable(R.drawable.like)
                    );
                }else{
                    tb.setBackgroundDrawable(
                            getResources().getDrawable(R.drawable.no_like)
                    );
                }
            }
        });

        Intent intent = getIntent();
        desing_name = intent.getStringExtra("tv_design_name");
        size = intent.getStringExtra("et_size");
        price = intent.getStringExtra("et_price");
        time = intent.getStringExtra("et_time");
        style = intent.getStringExtra("sp_style");

        ct_desing_name.setText(desing_name);
        ct_size.setText(size);
        ct_price.setText(price);
        ct_time.setText(time);

    }

    @Override
    protected void onResume() {
        super.onResume();

        buttonChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, ChatWithDesign.class);
                startActivity(intent);
            }
        });

        buttonBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, BookingActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btnFindStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, FindStyleActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnFindArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, FindArtistActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnMypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, TattooistMypageDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btnChatList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, TattooistChatList.class);
                startActivity(intent);
                finish();
            }
        });

        btnBookingList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, TattooistBookingList.class);
                startActivity(intent);
                finish();
            }
        });

        btnUploadDesign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, UploadDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btnUploadWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, UploadWork.class);
                startActivity(intent);
                finish();
            }
        });

        btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DesignActivity.this, LikeDesign.class);
            }
        });

    }

}
