package com.example.myapplication.SharedData;

import java.sql.Time;
import java.util.Date;

/**
 * Created by Delma Song on 2019-05-12
 */
public class TattooerBooking {

    String tattooerId;
    Date date;
    Time time;
    int price;
    String bodyPart;
    int size;
    String design;
    String bookerComment;
    String designId;

    public TattooerBooking() {
    }

    public String getTattooerId() {
        return tattooerId;
    }

    public void setTattooerId(String tattooerId) {
        this.tattooerId = tattooerId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getBodyPart() {
        return bodyPart;
    }

    public void setBodyPart(String bodyPart) {
        this.bodyPart = bodyPart;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getDesign() {
        return design;
    }

    public void setDesign(String design) {
        this.design = design;
    }

    public String getBookerComment() {
        return bookerComment;
    }

    public void setBookerComment(String bookerComment) {
        this.bookerComment = bookerComment;
    }

    public String getDesignId() {
        return designId;
    }

    public void setDesignId(String designId) {
        this.designId = designId;
    }

    @Override
    public String toString() {
        return "TattooerBooking{" +
                "tattooerId='" + tattooerId + '\'' +
                ", date=" + date +
                ", time=" + time +
                ", price=" + price +
                ", bodyPart='" + bodyPart + '\'' +
                ", size=" + size +
                ", design='" + design + '\'' +
                ", bookerComment='" + bookerComment + '\'' +
                ", designId='" + designId + '\'' +
                '}';
    }
}
