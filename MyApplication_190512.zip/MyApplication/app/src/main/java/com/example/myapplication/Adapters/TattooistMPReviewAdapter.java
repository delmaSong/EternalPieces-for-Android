package com.example.myapplication.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.myapplication.Items.ItemTattooistMPReview;
import com.example.myapplication.R;

import java.util.List;

/**
 * Created by Delma Song on 2019-05-04
 */
public class TattooistMPReviewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ItemTattooistMPReview> mDataList;
    public Context context;

    public TattooistMPReviewAdapter(List<ItemTattooistMPReview> mDataList) {
        this.mDataList = mDataList;
    }

    public static class MyRecyclerViewHolder extends RecyclerView.ViewHolder{

        TextView tt_title, tt_contents;
        ImageView item_img1, item_img2, item_img3;
        TextView tt_user_id, tt_write_date;
        RatingBar rating_bar;

        public MyRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            tt_title = (TextView)itemView.findViewById(R.id.tt_title);
            tt_contents = (TextView)itemView.findViewById(R.id.tt_contents);
            item_img1 = (ImageView)itemView.findViewById(R.id.item_img1);
            item_img2 = (ImageView)itemView.findViewById(R.id.item_img2);
            item_img3 = (ImageView)itemView.findViewById(R.id.item_img3);
            tt_user_id = (TextView)itemView.findViewById(R.id.tt_user_id);
            tt_write_date = (TextView)itemView.findViewById(R.id.tt_write_date);
            rating_bar = (RatingBar)itemView.findViewById(R.id.rating_bar);
        }
    }

    @NonNull
    @Override
    public MyRecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_review, viewGroup, false);
        context = viewGroup.getContext();
        return new MyRecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final MyRecyclerViewHolder holder = (MyRecyclerViewHolder)viewHolder;
        holder.tt_title.setText(mDataList.get(i).getTt_title());
        holder.tt_contents.setText(mDataList.get(i).getTt_contents());
        holder.tt_user_id.setText(mDataList.get(i).getTt_user_id());
        //추후 다른 날짜 데이터 받아서 뿌려주도록,,
        holder.tt_write_date.setText(mDataList.get(i).getTt_write_date());

        holder.item_img1.setImageResource(mDataList.get(i).getItem_img1());
        holder.item_img2.setImageResource(mDataList.get(i).getItem_img2());
        holder.item_img3.setImageResource(mDataList.get(i).getItem_img3());

        holder.rating_bar.setRating(mDataList.get(i).getRating_bar());
    }



    @Override
    public int getItemCount() {
        return mDataList.size();
    }
}
