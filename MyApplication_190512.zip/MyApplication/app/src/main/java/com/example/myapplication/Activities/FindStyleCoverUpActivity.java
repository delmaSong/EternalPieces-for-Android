package com.example.myapplication.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.myapplication.Adapters.FindStyleAdapter;
import com.example.myapplication.Items.ItemFindStyle;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;


public class FindStyleCoverUpActivity extends AppCompatActivity {

    ImageButton backButton;

    DrawerLayout dl;
    View drawer;

    ImageButton btnOpenDrawer;
    ImageButton btnCloseDrawer;

    Button btn_waterColor, btn_lettering, btn_coverUp, btn_blackNgray, btn_crayon;

    //드로어 내부 버튼
    Button btnFindStyle;
    Button btnFindArtist;
    Button btnMypage;
    Button btnChatList;
    Button btnBookingList;
    Button btnUploadDesign;
    Button btnUploadWork;
    Button btnLike;


    //값 임시저장 변수
    String title;
    String contents;
    String price, time, size;

    RecyclerView recyclerView;
    FindStyleAdapter adapter;
    List<ItemFindStyle> dataList;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_style_cover_up);

        backButton = (ImageButton) findViewById(R.id.buttonBack);

        //스타일 선택 버튼
        btn_waterColor = (Button)findViewById(R.id.btn_waterColor);
        btn_lettering = (Button)findViewById(R.id.btn_lettering);
        btn_coverUp = (Button)findViewById(R.id.btn_coverUp);
        btn_blackNgray = (Button)findViewById(R.id.btn_blackNgray);
        btn_crayon = (Button)findViewById(R.id.btn_crayon);

        //드로어 내부 버튼
        btnFindStyle = (Button)findViewById(R.id.btn_find_style);
        btnFindArtist = (Button)findViewById(R.id.btn_find_artist);
        btnMypage = (Button)findViewById(R.id.btn_mypage);
        btnChatList = (Button)findViewById(R.id.btn_chat_list);
        btnBookingList = (Button)findViewById(R.id.btn_booking_list);
        btnUploadDesign = (Button)findViewById(R.id.btn_upload_design);
        btnUploadWork = (Button)findViewById(R.id.btn_upload_work);
        btnLike = (Button) findViewById(R.id.btn_like);

        dl = (DrawerLayout)findViewById(R.id.dl_find_style_cover_up);
        drawer = (View)findViewById(R.id.dl_drawer);

        btnOpenDrawer = (ImageButton) findViewById(R.id.btnOpenDrawer);
        btnCloseDrawer = (ImageButton) findViewById(R.id.btnCloseDrawer);

        //드로어 오픈 버튼
        btnOpenDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.openDrawer(drawer);
            }
        });

        //드로어 클로즈 버튼
        btnCloseDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dl.closeDrawer(drawer);
            }
        });



        //인텐트로 값 받기
        Intent intent = getIntent();
        title = intent.getStringExtra("tv_design_name");
        contents = intent.getStringExtra("et_comment");
        price = getIntent().getStringExtra("et_price");
        time = getIntent().getStringExtra("et_time");
        size = getIntent().getStringExtra("et_size");






        //리사이클러뷰 적용
        recyclerView = findViewById(R.id.recycler_find_style);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);


        dataList = new ArrayList<>();
        dataList.add(new ItemFindStyle("제목", "내용"));
        dataList.add(new ItemFindStyle("제목", "내용"));
        dataList.add(new ItemFindStyle("제목", "내용"));

        adapter = new FindStyleAdapter(dataList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();








    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        if(resultCode == RESULT_OK){
            switch (requestCode){
                case 1111:
                    title = data.getStringExtra("tv_design_name");
                    contents = data.getStringExtra("et_comment");

                    dataList.add(new ItemFindStyle(title, contents));

                    adapter.notifyDataSetChanged();

                break;
            }
        }


    }

    protected void onResume(){
        super.onResume();




        //뒤로가기 버튼
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });








        //for choice style
        btn_waterColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btn_blackNgray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleBGActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btn_coverUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleCoverUpActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btn_crayon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleCrayonActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btn_lettering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleLetteringActivity.class);
                startActivity(intent);
                finish();
            }
        });












        //for drawer
        btnFindStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindStyleCoverUpActivity.class);
                startActivity(intent);

            }
        });

        btnFindArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, FindArtistActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnMypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, TattooistMypageDesign.class);
                startActivity(intent);
                finish();
            }
        });

        btnChatList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, TattooistChatList.class);
                startActivityForResult(intent, 1109);
                dl.closeDrawer(drawer);
            }
        });

        btnBookingList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, TattooistBookingList.class);
                startActivity(intent);
                finish();
            }
        });

        btnUploadDesign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, UploadDesign.class);
                startActivityForResult(intent, 1111);
                dl.closeDrawer(drawer);
            }
        });

        btnUploadWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, UploadWork.class);
                startActivity(intent);
                finish();
            }
        });

        btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FindStyleCoverUpActivity.this, LikeDesign.class);
                startActivity(intent);
            }
        });


    }



}


