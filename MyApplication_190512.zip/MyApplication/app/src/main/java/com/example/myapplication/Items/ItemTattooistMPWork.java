package com.example.myapplication.Items;

/**
 * Created by Delma Song on 2019-05-03
 */
public class ItemTattooistMPWork {

    public int item_img;

    public ItemTattooistMPWork(int item_img) {
        this.item_img = item_img;
    }

    public int getItem_img() {
        return item_img;
    }

    public void setItem_img(int item_img) {
        this.item_img = item_img;
    }
}
