package com.example.myapplication;

import android.util.Log;

/**
 * Created by Delma Song on 2019-05-11
 */
public class LogCheck {

    public void checkMoveData(){
    }
}
